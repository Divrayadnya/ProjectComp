# Vantara Digital — Pure HTML Company Profile

Modern responsive company profile website built with **pure HTML, CSS, and JavaScript**.
No framework, no npm, no build step, and ready for GitHub Pages.

## Features

- Premium responsive landing page
- Mobile navigation
- Dark / light mode with saved preference
- Dynamic service cards
- Animated statistics counter
- Filterable portfolio
- Testimonial slider
- FAQ accordion
- Scroll reveal animations
- Demo contact form
- Easy content editing from `SITE_DATA` inside `index.html`
- Fully self-contained: one HTML file

## Quick Start

1. Open `index.html` in a browser.
2. Find `const SITE_DATA = { ... }` near the bottom of the file.
3. Replace the sample company name, contact information, services, projects, testimonials, and FAQs.
4. Push the project to a GitHub repository.
5. Open **Repository Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose your main branch and `/ (root)`, then save.

## Contact Form

The current contact form is a front-end demo only. For a production static site, connect it to a form service such as Formspree / Getform / EmailJS, or your own API.

## File Structure

```text
company-profile-github/
├── index.html
└── README.md
```
